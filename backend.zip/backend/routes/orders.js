const express = require('express');
const router = express.Router();
const Order = require('../models/Order');
const Product = require('../models/Product');
const auth = require('../middleware/auth');

router.post('/', auth, async (req, res) => {
  const { items } = req.body; // [{product, qty}]
  let total = 0;
  const lineItems = [];
  for (const it of items) {
    const p = await Product.findById(it.product);
    if (!p) return res.status(400).json({ message: 'Product missing' });
    lineItems.push({ product: p._id, qty: it.qty, priceAtPurchase: p.price });
    total += p.price * it.qty;
  }
  const order = await Order.create({ buyer: req.userId, items: lineItems, total });
  res.json(order);
});

router.get('/me', auth, async (req, res) => {
  const orders = await Order.find({ buyer: req.userId }).populate('items.product');
  res.json(orders);
});

module.exports = router;
