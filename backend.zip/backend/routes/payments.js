const express = require('express');
const router = express.Router();
const axios = require('axios');
const Order = require('../models/Order');
const stripe = require('stripe')(process.env.STRIPE_SECRET || '');

// Paystack initialize transaction (server-side)
router.post('/paystack/init', async (req, res) => {
  const { email, amount, orderId } = req.body; // amount in kobo/ngn minor units
  try {
    const resp = await axios.post('https://api.paystack.co/transaction/initialize', {
      email, amount
    }, {
      headers: { Authorization: `Bearer ${process.env.PAYSTACK_SECRET}` }
    });
    // Save reference to order if needed
    res.json(resp.data);
  } catch (err) {
    res.status(500).json({ message: err.response?.data || err.message });
  }
});

// Paystack webhook (simple) - deploy webhook URL to Paystack dashboard
router.post('/paystack/webhook', express.raw({type: 'application/json'}), (req, res) => {
  // For security, verify Paystack signature if provided.
  // Here we accept and mark order paid after verifying offline (implement signature check)
  // parse body:
  try {
    const event = JSON.parse(req.body.toString());
    if (event.event === 'charge.success') {
      const ref = event.data.reference;
      // TODO: find order by reference and mark paid
    }
  } catch(e){}
  res.status(200).send('ok');
});

// Stripe create payment intent
router.post('/stripe/create-payment-intent', async (req, res) => {
  const { amount, currency='ngn' } = req.body;
  try {
    const pi = await stripe.paymentIntents.create({
      amount,
      currency,
    });
    res.json({ clientSecret: pi.client_secret });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Stripe webhook handler
router.post('/stripe/webhook', express.raw({type: 'application/json'}), (req, res) => {
  const sig = req.headers['stripe-signature'];
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('Stripe webhook signature verification failed', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }
  if (event.type === 'payment_intent.succeeded') {
    const pi = event.data.object;
    // TODO: fulfill order, mark paid
  }
  res.json({received: true});
});

module.exports = router;
