const express = require('express');
const router = express.Router();
const Product = require('../models/Product');
const auth = require('../middleware/auth');

router.get('/', async (req, res) => {
  const { q, category, min, max } = req.query;
  const filter = {};
  if (q) filter.title = { $regex: q, $options: 'i' };
  if (category) filter.category = category;
  if (min || max) filter.price = {};
  if (min) filter.price.$gte = Number(min);
  if (max) filter.price.$lte = Number(max);
  const products = await Product.find(filter).limit(100);
  res.json(products);
});

router.post('/', auth, async (req, res) => {
  const payload = req.body;
  payload.seller = req.userId;
  const product = await Product.create(payload);
  res.json(product);
});

router.get('/:id', async (req, res) => {
  const p = await Product.findById(req.params.id).populate('seller', 'name email');
  res.json(p);
});

module.exports = router;
